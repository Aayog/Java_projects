package com.alertBox;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class ShowAlertBox {

//	Alert infoAlert = new Alert(AlertType.INFORMATION);
//	Alert warningAlert = new Alert(AlertType.WARNING);
//	Alert errorAlert = new Alert(AlertType.ERROR);
//	Alert confirmAlert = new Alert(AlertType.CONFIRMATION);
	Alert typeAlert = new Alert(AlertType.NONE);

	public void showAlert(String mode, String message, String title) {

		if (mode.equals("I")) {
			typeAlert.setAlertType(AlertType.INFORMATION);
//			infoAlert.setTitle(title);
//			infoAlert.setContentText(message);
//			infoAlert.showAndWait();
		} else if (mode.equals("W")) {
			typeAlert.setAlertType(AlertType.WARNING);
//			warningAlert.setTitle(title);
//			warningAlert.setContentText(message);
//			warningAlert.showAndWait();
		} else if (mode.equals("E")) {
			typeAlert.setAlertType(AlertType.ERROR);
//			errorAlert.setTitle(title);
//			errorAlert.setContentText(message);
//			errorAlert.showAndWait();
		} else if (mode.equals("C")) {
			typeAlert.setAlertType(AlertType.CONFIRMATION);
//			confirmAlert.setTitle(title);
//			confirmAlert.setContentText(message);
//			confirmAlert.showAndWait();
		} else {
			typeAlert.setAlertType(AlertType.WARNING);
//			warningAlert.setTitle("You are not valid user");
//			warningAlert.setContentText("Login With Valid User");
//			warningAlert.showAndWait();
		}
		typeAlert.setTitle(title);
		typeAlert.setContentText(message);
		typeAlert.showAndWait();

	}
}
